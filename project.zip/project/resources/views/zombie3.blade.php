<table border="1">
    <tr>
        <td colspan="2">
            <center><img src="imageszombie/Zombie3.png" /></center>
        </td>
    </tr>
    <tr>
        <td>
            <ul>
                <li><a href="zombicaraladrillo">Zombi caraladrillo</a></li>
            </ul>
        </td>
        <td>
            Después de consultarlo con varios lobos de cuentos, decidió que<br>
            los cascos de paja y de madera no eran lo suficientemente resistentes,<br>
            y que había que pensar en los cascos de ladrilloDespués de consultarlo<br>
            con varios lobos de cuentos, decidió que los cascos de paja y de madera<br>
            no eran lo suficientemente resistentes, y que había que pensar en los<br>
            cascos de ladrillo
        </td>
    </tr>
</table>