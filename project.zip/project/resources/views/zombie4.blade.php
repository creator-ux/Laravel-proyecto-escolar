<center>
    <table border="1">
    <tr>
        <td colspan="2">
            <center><img src="imageszombie/zombitido1.png"></center>
        </td>
    </tr>
    <tr><center>
        <td>
            <ul>
                <li><a href="zombicomun">Zombidito</a></li>
            </ul>
        </td>
    </center>
    
    <center>
        <td>
            Al principio, al igual que los Zombies,<br>
            era alguien que odiaba a las plantas   <br>
            por naturaleza y el no tenia una personalidad <br>
            desarrollada a que era muy fácil de manipular,<br>
            su único propósito era destruira las plantas. <br>
            Aún así, a el le agrada pasar tiempo con las plantas<br>
        </td>
    </center>
    </tr>
    </table>
</center>