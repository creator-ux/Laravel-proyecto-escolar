<table border="1">
    <tr>
        <td colspan="2">
            <center><img src="imageszombie/Zombie2.png" /></center>
        </td>
    </tr>
    <tr>
        <td>
            <ul>
                <li><a href="zombicaracono">Zombi caracono</a></li>
            </ul>
        </td>
        <td>
            El zombi caracono avanza sin pensar como cualquier otro zombi.<br>
            Pero algo hizo que detuviera en seco, cogiera un cono del suelo<br>
            y se lo encasquetara en su mollera. Es que le va a la marcha.
        </td>
    </tr>
</table>