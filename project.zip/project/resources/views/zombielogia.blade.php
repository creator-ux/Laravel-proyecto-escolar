<table border="1">
    <tr>
        <td colspan="2">mi imagen</td>
    </tr>
    <tr>
        <td>
            <ul>
                <li><a href="zombicomun">Zombi de jardín común</a></li>
                <li><a href="zombicaracono">Zombi caracono</a></li>
                <li><a href="zombicaraladrillo">Zombi caraladrillo</a></li>
                <li><a href="zombidito">Zombidito</a></li>
            </ul>
        </td>
        <td>
            contenido
        </td>
    </tr>
</table>