<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/sopas', function () {
    return ('nocnocnoc');
});

Route::get('/', function () {
    return view('zombielogia');
});

Route::get('/zombicomun', function () {
    return view('zombie1');
});

Route::get('/zombicaracono', function () {
    return view('zombie2');
});

Route::get('/zombicaraladrillo', function () {
    return view('zombie3');
});

Route::get('/zombidito', function () {
    return view('zombie4');
});