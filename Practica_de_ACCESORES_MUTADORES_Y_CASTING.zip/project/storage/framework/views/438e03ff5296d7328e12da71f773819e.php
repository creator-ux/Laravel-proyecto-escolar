  <!-- se declara que se extenderá la plantilla padre -->

<?php $__env->startSection('content'); ?>  <!-- se especifíca la sección que se sustituye de la plantilla -->
     Aqui el contenido a desplegar desde segundaforma.blade.php<br>
     Sepa como lo logre pero lo logre!!!
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/maury/Páginas_prueba/Laravel/project/resources/views/plantillas2.blade.php ENDPATH**/ ?>