@extends('layouts.app')  <!-- se declara que se extenderá la plantilla padre -->

@section('content')  <!-- se especifíca la sección que se sustituye de la plantilla -->
     Aqui el contenido a desplegar desde segundaforma.blade.php<br>
     Sepa como lo logre pero lo logre!!!
@endsection