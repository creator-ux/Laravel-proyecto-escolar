<center><p>Este es el zombien controlador encargado de controlar los barrios perrones........<br>
Pero para entrar necesitaba poner una contraseña, pero el sistema fallo y no le aceptaba<br>
la contraseña waka waka------
</p></center>

<center><img src="imageszombie/ptm1.jpg"></center><?php /**PATH /home/maury/Páginas_prueba/Laravel/project/resources/views/zombies/zombiecontroller.blade.php ENDPATH**/ ?>