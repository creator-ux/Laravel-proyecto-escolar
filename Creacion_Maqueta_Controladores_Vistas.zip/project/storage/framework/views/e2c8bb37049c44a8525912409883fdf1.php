<center><p>Hola soy un zombie, mi nombre es <?php echo e($elnombre); ?> <?php echo e($elapellido); ?>,<br>
Carambaaa, si me jalo las variables a la primera, a veces soy una cosa pero barbara<br>
Ni estuvo tan JUERTE :)
</p><br></center>

<center><img src="imageszombie/csm1.jpg"></center>
<?php /**PATH /home/maury/Páginas_prueba/Laravel/project/resources/views/zombies/otrozombiealv.blade.php ENDPATH**/ ?>