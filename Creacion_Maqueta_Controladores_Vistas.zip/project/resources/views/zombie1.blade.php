
<table border="1">
    <tr>
        <td colspan="2">
            <center><img src="imageszombie/Zombie1.png"></center>
        </td>
    </tr>
    <tr><center>
        <td>
            <ul>
                <li><a href="zombicomun">Zombi de jardín común</a></li>
            </ul>
            
        </td>
    </center>
    
    <center>
        <td>
            El zombi básico odia el termino "básico".<br>
            El que no se considera cadáver común o<br>
            enemigo genérico, es un individuo maldición<br>
            y va a demostrar su personalidad aunque<br>
            tenga que pasar por delante.
        </td>
    </center>
    </tr>
</table>