<center><p>Hola soy un zombie, mi nombre es {{ $elnombre }} {{ $elapellido }},<br>
Carambaaa, si me jalo las variables a la primera, a veces soy una cosa pero barbara<br>
Ni estuvo tan JUERTE :)
</p><br></center>

<center><img src="imageszombie/csm1.jpg"></center>
