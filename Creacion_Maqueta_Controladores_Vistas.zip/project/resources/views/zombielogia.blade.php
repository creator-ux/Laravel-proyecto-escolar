<style>
    body {
        background-color: lightgoldenrodyellow;
    }
</style>

<table border="1">
    <tr>
        <td colspan="2">
            <center><img src="imageszombie/toniostar1.jpg"></center>
        </td>
    </tr>
    <tr>
        <td>
            <ul>
                <li><a href="zombicomun">Zombi de jardín común</a></li>
                <li><a href="zombicaracono">Zombi caracono</a></li>
                <li><a href="zombicaraladrillo">Zombi caraladrillo</a></li>
                {{-- <li><a href="zombidito">Zombidito</a></li> --}}
                <li><a href="zombidito">Zombidito</a></li>
                <li><a href="zombiecontrolador">Zombie controlador</a></li>
                <li><a href="zombiedinamico">Otro zombie Ctrl Dinámico ALV</a></li>
            </ul>
        </td>
        <td>
            Esto es una lista de todos<br>
            los zombies que se han visto<br>
            a lo largo de mi desayuno de<br>
            confleis.
        </td>
    </tr>
</table>